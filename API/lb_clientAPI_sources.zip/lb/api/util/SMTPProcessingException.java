package lb.api.util;

@SuppressWarnings("serial")
public class SMTPProcessingException extends Exception{
	public SMTPProcessingException(String message) {
		super(message);
	}
}
