<?php


class APIResourcesManager
{
	public static $urlApplication = 'https://mail.legalbox.com/restful/application';
	public static $urlSession = 'https://mail.legalbox.com/restful/session';
	public static $uploadUrl = 'https://mail.legalbox.com/restful/fileUpload';
	public static $downloadUrl = 'https://mail.legalbox.com/restful/fileDownload';
		
}
?>